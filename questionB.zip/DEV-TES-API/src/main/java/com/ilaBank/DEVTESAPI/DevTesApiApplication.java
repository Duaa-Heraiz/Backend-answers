package com.ilaBank.DEVTESAPI;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevTesApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevTesApiApplication.class, args);
	}

}
