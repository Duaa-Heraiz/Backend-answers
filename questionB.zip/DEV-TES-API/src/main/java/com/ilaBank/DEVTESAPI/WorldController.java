
package com.ilaBank.DEVTESAPI;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/world")

public class WorldController {


	
	@Autowired
	World world;
	
	@GetMapping("/get-world-countries")
	public List<WorldEntity> getAllCountries(){
		List<WorldEntity> allcountrieslist = world.findAll();
		return allcountrieslist;
		
	}
	
	
    @PostMapping("/add-country")
    public WorldEntity addCountry(@RequestBody WorldEntity employee) {
       
    	 WorldEntity savedCountry = world.save(employee);
    	 
    	 return savedCountry;
    }
    
  
}