
package com.ilaBank.DEVTESAPI;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "word_contries")
public class WorldEntity {

	    @Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)	
	    private Integer Id;
	    
	    @Column(name = "isoCode2", nullable = false)
	    private String isoCode2;
	    
	    @Column(name = "isoCode3", nullable = false)
	    private String isoCode3;
	    
	    @Column(name = "countryName", nullable = false)
	    private String countryName;
	    
	    @Column(name = "capital", nullable = false)
	    private String capital;
	 
	    @Column(name = "countryDialingCode", nullable = false)
	    private String countryDialingCode;
	 
	 
	    public WorldEntity() {
	  
	    }
	 
	    public WorldEntity(String country, String capital, String DialingCode) {
	         this.countryName = country;
	         this.capital = capital;
	         this.countryDialingCode = DialingCode;
	    }
	 
	   
	        public Integer getId() {
	        return Id;
	    }
	    public void setId(Integer Id) {
	        this.Id = Id;
	    }
	    
	    
	    public String getiso2() {
	        return isoCode2;
	    }
	    public void setiso2(String isoCode2) {
	        this.isoCode2 = isoCode2;
	    }
	 
	    
	    public String getiso3() {
	        return isoCode3;
	    }
	    public void setiso3(String isoCode3) {
	        this.isoCode3 = isoCode3;
	    }
	    
	    
	   	    public String getcountry() {
	        return countryName;
	    }
	    public void setcountryName(String countryName) {
	        this.countryName = countryName;
	    }
	 
	   
	    public String getcapital() {
	        return capital;
	    }
	    public void setcapital(String capital) {
	        this.capital = capital;
	    }
	 
	   
	    public String getDialingCode() {
	        return countryDialingCode;
	    }
	    public void setcountryDialingCode(String countryDialingCode) {
	        this.countryDialingCode = countryDialingCode;
	    }

	    @Override
	    public String toString() {
	        return "countryName [Id=" + Id + ", counrty=" + countryName + ", capital=" + capital
	       + "]";
	    }
	 
	}